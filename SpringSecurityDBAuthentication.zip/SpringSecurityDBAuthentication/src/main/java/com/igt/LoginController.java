package com.igt;

import java.security.Principal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.dao.UserDAO;

@Controller
public class LoginController {
	static ResultSet rs;

	@RequestMapping(value = "/")
	public String welcome(Model model) {
		model.addAttribute("name", "Home Page");
		model.addAttribute("description", "unsecured page !");
		return "login";

	}

	@RequestMapping("/index")
	public <HttpResponse> String admin(Authentication authentication, Model model, Principal principal)
			throws SQLException {

		String loggedInUserName = principal.getName();

		model.addAttribute("user", loggedInUserName);
		model.addAttribute("name", "Spring Security Custom Login Demo");
		model.addAttribute("description", "Protected page !");

		List<SimpleGrantedAuthority> authList = (List<SimpleGrantedAuthority>) authentication.getAuthorities();
		ArrayList<String> authorityList = new ArrayList<>();
		String role = "";
		for (SimpleGrantedAuthority authority : authList) {
			role = authority.getAuthority();
			authorityList.add(role);
		}
		model.addAttribute("sprintList", UserDAO.getSprintList());

		model.addAttribute("authList", authorityList);

		return "dropdown";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(ModelMap model) {

		return "login";

	}

	@RequestMapping(value = "/redirect", method = RequestMethod.POST)
	public String redirect(ModelMap model) throws SQLException {
		Map<Integer, String> devCheckListpresprint = UserDAO.description_developerpresprint();
		Map<Integer, String> devCheckListduringsprint = UserDAO.description_developerduring();
		Map<Integer, String> devCheckListpostsprint = UserDAO.description_developerpost();

		/*
		 * while (i.hasNext()) { Map.Entry e = (Map.Entry) i.next(); Integer[] k
		 * = (Integer[]) e.getKey(); String []v = (String[]) e.getValue();
		 * session.setAttribute("k", k); session.setAttribute("v", v); }
		 */

		model.addAttribute("MapDescription_developerpre", devCheckListpresprint);
		model.addAttribute("MapDescription_developerduring", devCheckListduringsprint);
		model.addAttribute("MapDescription_developerpost", devCheckListpostsprint);
		/*
		 * model.addAttribute("listDescription_developer",devCheckList);
		 * System.out.println("SIZE :" + devCheckList != null ?
		 * devCheckList.size() : " ZERO" );
		 */ return "redirect";

	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(ModelMap model) {

		model.addAttribute("message", "You have successfully logged off from application !");
		return "logout";

	}

	@RequestMapping(value = "/loginError", method = RequestMethod.GET)
	public String loginError(ModelMap model) {
		model.addAttribute("error", "true");
		return "login";

	}

	@RequestMapping("/presprint")
	public String presprint(HttpServletRequest request)
    {
    	try
		{
    		String names="";
    		String checkpointlist[]=request.getParameterValues("checkpointlist");
    		for(int pre=0;pre<checkpointlist.length;pre++){
    		    names+=checkpointlist[pre];
    	}
		
		}
		catch(Exception ex)
		{
			System.out.println("Exception = "+ex);
		}
		return "presprint";
    
	
	}

	@RequestMapping("/postsprint")
	public String postsprint(Model model) {

		return "postsprint";

	}

	@RequestMapping("/duringsprint")
	public String multiplecheckbox(Model model) {

		return "duringsprint";

	}

}
