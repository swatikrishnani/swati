package com.model;

import java.util.List;

public class Checkpoint {
	private int checkpoint_id;
	private List<Object> checkpointDesc;
	private List<Checkpointgroup> checkpointgroup;

	public int getCheckpoint_id() {
		return checkpoint_id;
	}

	public void setCheckpoint_id(int checkpoint_id) {
		this.checkpoint_id = checkpoint_id;
	}

	public List<Object> getCheckpointDesc() {
		return checkpointDesc;
	}

	public void setCheckpointDesc(List<Object> checkpointDesc) {
		this.checkpointDesc = checkpointDesc;
	}

	public List<Checkpointgroup> getCheckpointgroup() {
		return checkpointgroup;
	}

	public void setCheckpointgroup(List<Checkpointgroup> checkpointgroup) {
		this.checkpointgroup = checkpointgroup;
	}
}
