package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserDAO {
	static ResultSet result;
	static String Result;
	static List sprintno;
	static Statement statement;
	static Connection connection;
	static {
		try {
			// Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost/checklist?user=root&password=root");

			statement = connection.createStatement();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static List getSprintList() throws SQLException{

		PreparedStatement pst = connection.prepareStatement("Select * from sprint");
				  result = pst.executeQuery();
				  ArrayList<String> sprintno=new ArrayList<>();
				  while(result.next()){
					  sprintno.add(result.getString("Sprint_No"));

        }

		return sprintno;
	}
	
	public static Map<Integer,String> description_developerpresprint() throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='Presprint'");
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerpresprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerpresprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerpresprint;
		
	}
	public static Map<Integer,String> description_developerduring() throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='duringsprint'");
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerduringsprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerduringsprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerduringsprint;
	}

	public static Map<Integer, String> description_developerpost() throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='postsprint'");
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerpostsprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerpostsprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerpostsprint;
	}
	public static Map<Integer, String> checklisttransaction() throws SQLException {
		PreparedStatement pst = connection.prepareStatement("insert into checklist_transactions values(?,?,?)");
		  result = pst.executeQuery();
		  Map<Integer,String> checklisttransaction =new HashMap<Integer,String>();
		  while(result.next()){
			 
		  }
		return checklisttransaction;
	}



}
