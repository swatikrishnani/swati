package com.dao;

import java.sql.*;  
public class UserDAO{  
	static ResultSet result;
	static String Result;
	static Statement statement;
public static void connection(){
	 try{
		//Class.forName("com.mysql.jdbc.Driver").newInstance();
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/checklist?user=root&password=root");

		statement = connection.createStatement() ;
	 }
	
	

catch(Exception e)
{
     e.printStackTrace();
}
}

public static ResultSet fetchdeveloper() throws SQLException
{
	result =statement.executeQuery("SELECT CheckPoint_Description from checkpoints LIMIT 5") ;
        

	return result;
}
}