package com.igt.dao;

import java.sql.*;
import java.util.List;

public class LoginDAO {
    static ResultSet result;
    static int resultEnable;
    static Statement stmt;
    static PreparedStatement pst;
    static String rs = null;
    static List<String> sprintno;
    static Connection connection = DBConnectionDAO.getConnection();

    public static List<String> signUpTransaction(String Password,
            final String[] Role, String Display_Name, String Employee_ID) {

        try {

            for (String rolelist : Role) {
                Integer rolelistInt = new Integer(rolelist);
                String query = "insert into users(Password,Role_ID,"
                        + "Display_Name,Employee_ID,enabled) values('"
                        + Password + "','" + rolelistInt + "','" + Display_Name
                        + "','" + Employee_ID + "', 1)";
                stmt = connection.createStatement();

                stmt.executeUpdate(query);
            }
        }

        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String forgotPasswordTransaction(String password,
            String employee_ID) throws SQLException {

        String query = "update users set password ='" + password
                + "' where employee_ID = '" + employee_ID + "'";
        pst = connection.prepareStatement(query);
        resultEnable = pst.executeUpdate();
        return rs;

    }

    public static void logout() {
        try {
            connection.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }

    }

}
