package com.igt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.igt.controller.ChecklistController;
import com.igt.controller.LoginController;
import com.igt.model.Checkpoint;
/**
* @author Swati Krishnani,Litika kakkar,Rishabh Pandey.
* @since   2018-05-24
*/
public class ChecklistDAO {
    static ResultSet result;
    static int resultEnable;
    static Statement stmt;
    static PreparedStatement pst;
    static String rs = null;
    static List<String> sprintno;

    /**
    *  This method is used to add Connection.
    *
    */

    private static Connection connection = DBConnectionDAO.getConnection();


    /**
     * This method is used for selecting presprint checkpoints.
    */
    public static Map<Integer, String> description_developerpresprint(
            final String role) throws SQLException {
        pst = connection.prepareStatement(
                "select * from checkpoints where Checkpoint_Group='Presprint'"
                        + " AND Role_ID in(select Role_ID from role where "
                        + "Role_Description='" + role + "')");
        result = pst.executeQuery();
        Map<Integer, String> listDescription_developerpresprint =
                new HashMap<Integer, String>();
        while (result.next()) {
            listDescription_developerpresprint.put(result.getInt(1),
                    result.getString(2));
        }
        return listDescription_developerpresprint;
    }
   
    /**
     * This method is used for selecting duringsprint checkpoints.
    */
    public static Map<Integer, String> description_developerduring(String role)
            throws SQLException {
        pst = connection.prepareStatement(
                "select * from checkpoints where Checkpoint_Group="
                + "'duringsprint'"
                        + " AND Role_ID in(select Role_ID from role "
                        + "where Role_Description='"
                        + role + "')");
        result = pst.executeQuery();
        Map<Integer, String> listDescription_developerduringsprint =
                new HashMap<Integer, String>();
        while (result.next()) {
            listDescription_developerduringsprint.put(result.getInt(1),
                    result.getString(2));
        }
        return listDescription_developerduringsprint;
    }

    /**
     * This method is used for selecting postsprint checkpoints.
    */
    public static Map<Integer, String> description_developerpost(String role)
            throws SQLException {
        pst = connection.prepareStatement(
                "select * from checkpoints where Checkpoint_Group='postsprint'"
                        + " AND Role_ID in(select Role_ID from role "
                        + "where Role_Description='"
                        + role + "')");
        result = pst.executeQuery();
        Map<Integer, String> listDescription_developerpostsprint =
                new HashMap<Integer, String>();
        while (result.next()) {
            listDescription_developerpostsprint.put(result.getInt(1),
                    result.getString(2));
        }
        return listDescription_developerpostsprint;
    }
    /**
     * This method is inserting values to checklist transaction table.
    */
    public static List<String> checklistTransaction(List<Checkpoint> checkPointList) {

        try {

            for (Checkpoint checkPoint : checkPointList) {
                Integer checkPointInt = new Integer(checkPoint.getCheckpointDesc());
                String remarks= checkPoint.getRemark();
                String query = "insert into checklist_transactions(Sprint_ID,"
                        + "Role_ID," + "CheckPoint_ID,Employee_ID,enabled,Remarks)"
                                + " values("
                        + checkPoint.getSprintNumber() + ",'" + checkPoint.getRoleId() + "','" + checkPointInt
                        + "','" + checkPoint.getEmployeeID() + "','" + checkPoint.getEnabled() + "','" + remarks + "')";
                stmt = connection.createStatement();

                stmt.executeUpdate(query);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    

    /**
     * This method is used to delete values from checklist transaction table.
    */
    public static List<String> checklistdeletetransaction(Object Sprint_ID,
            final Object Role_ID, final String[] checkpointlist,
            String Employee_ID) {

        try {

            for (String checkPoint : checkpointlist) {
                Integer checkPointInt = new Integer(checkPoint);
                String query = "DELETE FROM checklist_transactions where "
                        + "CheckPoint_ID='"
                        + checkPointInt + "' AND Sprint_ID='" + Sprint_ID
                        + "' AND Role_ID='" + Role_ID + "' AND Employee_ID='"
                        + Employee_ID + "'";
                stmt = connection.createStatement();

                stmt.executeUpdate(query);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static List<String> checklistinserttransaction(Object Sprint_ID,
            final Object Role_ID, final String[] checkpointlist,
            String Employee_ID,Integer enabled,final String[] remarkListAsString) {
try{
            for (int i=0; i<checkpointlist.length;i++) {
            	 
                Integer checkPointInt = new Integer(checkpointlist[i]);
              
                String query = "insert into checklist_transactions(Sprint_ID,"
                + "Role_ID," + "CheckPoint_ID,Employee_ID,enabled,Remarks)"
                        + " values("
                + Sprint_ID+ ",'" + Role_ID+ "','" + checkPointInt
                + "','" + Employee_ID + "','" + enabled + "','" + remarkListAsString[i] + "')";
        stmt = connection.createStatement();

                stmt = connection.createStatement();

                stmt.executeUpdate(query);
            
            }
        
        }catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
     * This method select role id's from role table.
    */
    public static String role() throws SQLException {

        pst = connection
                .prepareStatement("select * from role where Role_Description='"
                        + ChecklistController.role + "'");
        result = pst.executeQuery();
        while (result.next()) {
            rs = result.getString(1);
        }
        return rs;
    }
    /**
     * This method is used to display Employee name.
    */

    public static String displayName(String role) throws SQLException {
        String query = "select Display_Name from users where Employee_ID= '"
                + LoginController.loggedInUserName + "' "
                + " AND Role_ID in(select Role_ID from role where "
                + "Role_Description " + "='" + role + "')";
        pst = connection.prepareStatement(query);
        result = pst.executeQuery();
        while (result.next()) {
            rs = result.getString(1);
        }
        return rs;
    }
    /**
     * This method is used for selecting previouslyselected checkpoints.
    */

    public static Map<Integer, String> previousSelectedItems(final Object sprint,
            final Object role, final int enabled) throws SQLException {

        Map<Integer, String> selectedList =  new HashMap<Integer, String>();
        String query = "select checklist_transactions.CheckPoint_ID,checklist_transactions.Remarks from "
                + "checklist_transactions where " + "Sprint_ID in(select "
                + "Sprint_ID from " + "sprint where Sprint_No='" + sprint + "')"
                + " AND Role_ID in(select Role_ID from role where "
                + "Role_Description='" + role + "')" + " AND Employee_ID= '"
                + LoginController.loggedInUserName + "' " + " AND enabled='" + enabled + "'  ";
        // System.out.println("SQL QUERY : "+query);
        pst = connection.prepareStatement(query);

        result = pst.executeQuery();
        while (result.next()) {
            selectedList.put(result.getInt(1),
                    result.getString(2));
        }


        return selectedList;
    }
    public static List<Integer> previousSelectedItemscheckpointinsert(final Object sprint,
            final Object role, final int enabled) throws SQLException {

        List<Integer> selectedList =  new ArrayList<Integer>();
        String query = "select checklist_transactions.CheckPoint_ID from "
                + "checklist_transactions where " + "Sprint_ID in(select "
                + "Sprint_ID from " + "sprint where Sprint_No='" + sprint + "')"
                + " AND Role_ID in(select Role_ID from role where "
                + "Role_Description='" + role + "')" + " AND Employee_ID= '"
                + LoginController.loggedInUserName + "' " + " AND enabled='" + enabled + "'  ";
        // System.out.println("SQL QUERY : "+query);
        pst = connection.prepareStatement(query);

        result = pst.executeQuery();
        while (result.next()) {
            selectedList.add(result.getInt(1));
        }


        return selectedList;
    }
    public static List<String> previousSelectedItemsremarkinsert(final Object sprint,
            final Object role, final int enabled) throws SQLException {

        List<String> selectedList =  new ArrayList<String>();
        String query = "select checklist_transactions.Remarks from "
                + "checklist_transactions where " + "Sprint_ID in(select "
                + "Sprint_ID from " + "sprint where Sprint_No='" + sprint + "')"
                + " AND Role_ID in(select Role_ID from role where "
                + "Role_Description='" + role + "')" + " AND Employee_ID= '"
                + LoginController.loggedInUserName + "' " + " AND enabled='" + enabled + "'  ";
        // System.out.println("SQL QUERY : "+query);
        pst = connection.prepareStatement(query);

        result = pst.executeQuery();
        while (result.next()) {
            selectedList.add(result.getString(1));
        }
        return selectedList;



    }
    /**
     * This method is used for updating enabled functionality.
    */
    public static String EnabledTransaction(Object Sprint_ID, Object Role_ID,
            final String[] checkpointlist, String Employee_ID)
                    throws SQLException {

        for (String checkpoint_list : checkpointlist) {
            Integer checkpointlistInt = new Integer(checkpoint_list);
            String query = "update checklist_transactions set enabled = 1"
                    + " where Sprint_ID='"
                    + Sprint_ID + "' AND Role_ID='" + Role_ID
                    + "' AND CheckPoint_ID='" + checkpointlistInt
                    + "' AND Employee_ID='" + Employee_ID + "'";
            stmt = connection.createStatement();
            pst = connection.prepareStatement(query);
            resultEnable = pst.executeUpdate();
        }
        return rs;
    }

	
}
