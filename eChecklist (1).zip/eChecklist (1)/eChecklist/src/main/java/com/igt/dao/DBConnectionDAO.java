package com.igt.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectionDAO {
    private static String url = "jdbc:mysql://localhost:3306/checklist";
    private static String driverName = "com.mysql.jdbc.Driver";
    private static String username = "root";   
    private static String password = "root";
    private static Connection connection;

    public static Connection getConnection() {
        try {
            Class.forName(driverName);
            try {
          connection = DriverManager.getConnection(url, 
                        username, password);
            } catch (SQLException ex) {
            System.out.println("Failed database connection."); 
            }
        } catch (ClassNotFoundException ex) {
           
            System.out.println("Driver not found."); 
        }
        return connection;
    }
}