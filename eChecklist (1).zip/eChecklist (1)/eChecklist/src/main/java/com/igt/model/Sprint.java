package com.igt.model;

public class Sprint {
	private int sprint_id;
	private String Sprint_no;

	public int getSprint_id() {
		return sprint_id;
	}

	public void setSprint_id(int sprint_id) {
		this.sprint_id = sprint_id;
	}

	public String getSprint_no() {
		return Sprint_no;
	}

	public void setSprint_no(String sprint_no) {
		Sprint_no = sprint_no;
	}

}
