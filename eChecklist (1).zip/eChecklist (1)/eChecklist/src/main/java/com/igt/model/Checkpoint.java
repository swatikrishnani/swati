package com.igt.model;

public class Checkpoint {
    private Integer checkpointDesc;
    private Object sprintNumber;
    private String roleId;
    private String employeeID;
    private int enabled;
    private String remark;
    private int checkpointdisc;
    private String[] RemarkList;

    public String[] getRemarkList() {
        return RemarkList;
    }

    public void setRemarkList(String[] remarkList) {
        RemarkList = remarkList;
    }

    public int getCheckpointdisc() {
        return checkpointdisc;
    }

    public void setCheckpointdisc(int strings) {
        this.checkpointdisc = strings;
    }

    public Integer getCheckpointDesc() {
        return checkpointDesc;
    }

    public void setCheckpointDesc(Integer checkpointDesc) {
        this.checkpointDesc = checkpointDesc;
    }

    public Object getSprintNumber() {
        return sprintNumber;
    }

    public void setSprintNumber(Object object) {
        this.sprintNumber = object;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleList) {
        this.roleId = roleList;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String loggedInUserName) {
        this.employeeID = loggedInUserName;
    }

    public int getEnabled() {
        return enabled;
    }

    public void setEnabled(int enabled) {
        this.enabled = enabled;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

	public void setCheckpointdisc(String[] strings) {
		// TODO Auto-generated method stub
		
	}



}
