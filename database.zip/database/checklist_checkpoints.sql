-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: checklist
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `checkpoints`
--

DROP TABLE IF EXISTS `checkpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkpoints` (
  `CheckPoint_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CheckPoint_Description` varchar(80) DEFAULT NULL,
  `Checkpoint_Group` varchar(45) NOT NULL,
  `Role_ID` int(11) NOT NULL,
  PRIMARY KEY (`CheckPoint_ID`),
  KEY `Role_ID_idx` (`Role_ID`),
  CONSTRAINT `RoleID` FOREIGN KEY (`Role_ID`) REFERENCES `role` (`Role_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkpoints`
--

LOCK TABLES `checkpoints` WRITE;
/*!40000 ALTER TABLE `checkpoints` DISABLE KEYS */;
INSERT INTO `checkpoints` VALUES (1,'Functional grooming is completed','Presprint',2),(2,'Allocation of work during sprint planning is completed','Presprint',2),(3,'Update Technical approach in JIRA and mark the JIRA in-Progress','Presprint',2),(4,'Test Case scenario walkthrough with FAT testers is completed','Presprint',2),(5,'Plan for interim release is created','Presprint',2),(6,'Unit testing & Jnuit-70% and above Jnuit Coverage','duringsprint',2),(7,'JIRA is updated along with each step','duringsprint',2),(8,'Interim Release at the end of First week is successful','duringsprint',2),(9,'Lessons learnt discussed during sprint review. Retrospective preparation','postsprint',2),(10,'Sprint day wise execution plan is completed','Presprint',1),(11,'Resource and capacity planning is completed','Presprint',1),(12,'core team communication for committed stories is completed - 2nd day of sprint','Presprint',1),(13,'Making sure the availability of environment','Presprint',1),(14,'Sprint planning is completed','duringsprint',1),(15,'Ensured interim testing done during ongoing sprint','duringsprint',1),(16,'Ensured proper unit testing and CI Testing','duringsprint',1),(17,'Released documentation is reviewed','postsprint',1),(18,'Run effective Sprint retorspective and manage continues improvement plan','postsprint',1),(19,'Participated in SOS Retrospective','postsprint',1),(20,'Sprint review with team members for lessons learned is completed','postsprint',1),(21,'Requirement gathering is completed','Presprint',3),(22,'Requirement analysis + Brainstorming is completed','Presprint',3),(23,'Requirement verification is completed','Presprint',3),(24,'Following JIRA documentation is completed','Presprint',3),(25,'Scope','Presprint',3),(26,'Acceptance Criteria','Presprint',3),(27,'Limitations','Presprint',3),(28,'Assumptions','Presprint',3),(29,'Impact analysis','Presprint',3),(30,'Requirement approval for each user story from Lead BA\'s','Presprint',3),(31,'Planned FP calculations are done','Presprint',3),(32,'Sprint backlog grooming is completed','Presprint',3),(33,'Attend Scrum and Integration Testers grooming with Leads BA\'s','Presprint',3),(34,'FPs are estimated','Presprint',3),(35,'Verification of FP\'s bt BE team is completed','Presprint',3),(36,'Test Case Review is completed','duringsprint',3),(37,'Improved User story format','duringsprint',3),(38,'DOD verification is completed before delivery','duringsprint',3),(39,'Demo to Product Owner is completed successfully','duringsprint',3),(40,'Following Release Documentation is completed','duringsprint',3),(41,'Release notes from BA','duringsprint',3),(42,'RPM from developers','duringsprint',3),(43,'Test exit from QA','duringsprint',3),(44,'Configuration Guide Update','duringsprint',3),(45,'Project and Product documentation as per Story','duringsprint',3),(46,'Installation Instruction from deployment team','duringsprint',3),(47,'Lesson learnt','postsprint',3),(48,'Attended grooming with offshore BA from onsite BA\'s','Presprint',4),(49,'Impact analyis and provide review comments are reviewed','Presprint',4),(50,'QC- Test cases along with integration are created and uploaded','Presprint',4),(51,'Test case walk through with Scrum BA(and approval) is completed ','Presprint',4),(52,'QC - Requirements are Loaded','Presprint',4),(53,'QC - Requirement mapping is completed','Presprint',4),(54,'Prepaparation of test data is finished','Presprint',4),(55,'Regression test suites are created/updated','Presprint',4),(56,'Attended Technical grooming with Core team','Presprint',4),(57,'JIRA is updated with required test scenarios','Presprint',4),(58,'CI results are checked','duringsprint',4),(59,'Klockwork report are checked','duringsprint',4),(60,'QC -test cases are executed (Daily)','duringsprint',4),(61,'All FAT defects are logged in JIRA/QC','duringsprint',4),(62,'Test evidence are attached to JIRA','duringsprint',4),(63,'JIRA is updated with relevant comments Observations','duringsprint',4),(64,'FAT test Acceptance criteria is met','duringsprint',4),(65,'Review and updates of all the open defects in JIRA with BA\'s','duringsprint',4),(66,'All the relevant logs are checked thoroughly','duringsprint',4),(67,'Fat sign off(with Exit criteria) completed','postsprint',4),(68,'DOD - QA section is updated','postsprint',4),(69,'Sharing Lessons learnt','postsprint',4),(70,'Functional analysis is completed','Presprint',5),(71,'Allocation of work','Presprint',5),(72,'Test Case scenario walkthrough with team is completed','Presprint',5),(73,'Preparation of test data is completed(if applicable)','duringsprint',5),(74,'CI Test case writing and execution (on product and project both)','duringsprint',5),(75,'Project POM with all latest stable product components is updated','duringsprint',5),(76,'Product nigthly build POMs are updated','duringsprint',5),(77,'Lessons learnt discussed during sprint review. Retrospective preparation','postsprint',5),(78,'FAT Testing is completed','Presprint',6),(79,'Attended grooming with offshore BA from onsite BA\'s','Presprint',6),(80,'Remaining integration testers are groomed','Presprint',6),(81,'I impact analysis reviewed successfully','Presprint',6),(82,'Attended Technical grooming with Core team ','Presprint',6),(83,'Relevant JIRA is updated with test Scenarios','Presprint',6),(84,'Suggest Developers how to write continuous test cases','Presprint',6),(85,'Review SQUACE defects and work with core team to align in backlogs','Presprint',6),(86,'Preparation of test data is completed ','duringsprint',6),(87,'QC - E2E test Cases(Daily) are created and uploaded','duringsprint',6),(88,'Regression test suite are created/updated','duringsprint',6),(89,'JIRA & QC are updated with test results','postsprint',6),(90,'FAT defect leakage is idenfied','postsprint',6),(91,'Integration sign off (with Exit Criteria)_is completed','postsprint',6),(92,'All the relevant logs are checked','postsprint',6),(93,'Sharing Lessons learnt','postsprint',6);
/*!40000 ALTER TABLE `checkpoints` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-25 18:44:14
