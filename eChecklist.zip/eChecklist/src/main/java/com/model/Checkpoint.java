package com.model;

public class Checkpoint {
	private boolean isPreviouslySelected;
	private String checkpointDesc;
	public boolean isPreviouslySelected() {
		return isPreviouslySelected;
	}
	public void setPreviouslySelected(boolean isPreviouslySelected) {
		this.isPreviouslySelected = isPreviouslySelected;
	}
	public String getCheckpointDesc() {
		return checkpointDesc;
	}
	public void setCheckpointDesc(String checkpointDesc) {
		this.checkpointDesc = checkpointDesc;
	}

}
