package com.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.igt.LoginController;

public class ChecklistDAO {
	static ResultSet result;
	static String Result;
	static int result1;
	static List<String> sprintno;
	static Statement statement;
	static Connection connection;
	static {
		try {
			// Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost/checklist?user=root&password=root");

			statement = connection.createStatement();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static List<String> getSprintList() throws SQLException{

		PreparedStatement pst = connection.prepareStatement("Select * from sprint");
				  result = pst.executeQuery();
				  ArrayList<String> sprintno=new ArrayList<>();
				  while(result.next()){
					  sprintno.add(result.getString("Sprint_No"));
        }
		return sprintno;
	}
	public static List<String> getAllRole_Description() throws SQLException{

		PreparedStatement pst = connection.prepareStatement("Select * from role");
				  result = pst.executeQuery();
				  ArrayList<String> listDescription=new ArrayList<>();
				  
				  while(result.next()){
					  listDescription.add(result.getString("Role_Description"));
				  }
			
		return listDescription;
	}
	public static List<String> getAllRole_ID(String role) throws SQLException{
		ArrayList<String> listDescription = null;
		
		PreparedStatement pst = connection.prepareStatement("Select * from role where Role_Description='"+ role + "'" );
				  result = pst.executeQuery();
				  listDescription=new ArrayList<>();
				  
				  while(result.next()){
					  listDescription.add(result.getString("Role_ID"));
				  }
				return listDescription;
				
		
	}
	public static Map<Integer,String> description_developerpresprint( String role) throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='Presprint'" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')" );
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerpresprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerpresprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerpresprint;
	}
	
	public static Map<Integer,String> description_developerduring(String role) throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='duringsprint'" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')");
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerduringsprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerduringsprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerduringsprint;
	}

	public static Map<Integer, String> description_developerpost(String role) throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='postsprint'" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')");
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerpostsprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerpostsprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerpostsprint;
	}
	public static List<String> checklisttransaction(Object Sprint_ID,Object Role_ID,String[] checkpointlist,String Employee_ID)
	{
		Statement stmt;
		try {

			for (String checkPoint : checkpointlist) {
				Integer checkPointInt = new Integer(checkPoint);
				String query = "insert into checklist_transactions(Sprint_ID,Role_ID,CheckPoint_ID,Employee_ID,Enabled) values(" + Sprint_ID+ ",'" + Role_ID + "','" + checkPointInt + "','" + Employee_ID + "',1)";
				stmt = connection.createStatement();

				stmt.executeUpdate(query);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static List<String> checklistupdatetransaction(Object Sprint_ID,Object Role_ID,String[] checkpointlist,String Employee_ID)
	{
		Statement stmt;
		try {

			for (String checkPoint : checkpointlist) {
				Integer checkPointInt = new Integer(checkPoint);
				String query = "update checklist_transactions set CheckPoint_ID='" + checkPointInt +"' where Sprint_ID='" + Sprint_ID +"' and Role_ID='" + Role_ID +"' and Employee_ID='" + Employee_ID +"'";
				stmt = connection.createStatement();

				stmt.executeUpdate(query);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static List<String> signuptransaction(String Password,String Display_Name,String Employee_ID)
	{
		Statement stmt;
		try {
				String query = "insert into users(Password,Role_ID,Display_Name,Employee_ID,enabled) values('" + Password+"','" + getAllRole_ID(LoginController.Role)+"','"+ Display_Name+ "','" + Employee_ID + "', 1)";
				stmt = connection.createStatement();
 
				stmt.executeUpdate(query);
			}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static String role() throws SQLException {
		 String rs="";
		PreparedStatement pst = connection.prepareStatement("select * from role where Role_Description='"+LoginController.role+"'");
		  result = pst.executeQuery();
		  while(result.next()){
			  rs=result.getString(1);
		  }
		return rs;
	}
	public static String displayName(String role) throws SQLException {
        String rs = "";
        String query = "select Display_Name from users where Employee_ID= '" + LoginController.loggedInUserName +"' " + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')";
        PreparedStatement pst = connection.prepareStatement(query);

        result = pst.executeQuery();
		  while(result.next()){
			  rs=result.getString(1);
		  }
		return rs;
	
 }


        public static String forgotPasswordTransaction(String password,String employee_ID) throws SQLException{
        	 
        	String rs="";
        	String query = "update users set password ='" + password + "' where employee_ID = '" + employee_ID + "'";
        	PreparedStatement pst= connection.prepareStatement(query);
        	result1 =pst.executeUpdate();
 			return rs;
        	
        }
        
        public static Set<Integer> previousSelectedItems(String selectedSprint, String role) throws SQLException {

		Set<Integer> selectedList = new HashSet<Integer>();
		String query = "select checklist_transactions.CheckPoint_ID from checklist_transactions where Sprint_ID in(select Sprint_ID from sprint where Sprint_No='"
				+ selectedSprint + "')" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')" + " AND Employee_ID= '" + LoginController.loggedInUserName +"'" ;
		//System.out.println("SQL QUERY : "+query);
		PreparedStatement pst = connection.prepareStatement(query);

		result = pst.executeQuery();
		while (result.next()) {
				try{
			Integer rs = new Integer(result.getString(1));
			selectedList.add(rs);
				}catch (Exception e) {
					e.printStackTrace();
				}
		}
		return selectedList;
	}
}
