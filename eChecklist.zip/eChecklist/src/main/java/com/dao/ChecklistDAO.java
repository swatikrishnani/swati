package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.igt.LoginController;

public class ChecklistDAO {
	static ResultSet result;
	static String Result;
	static List<String> sprintno;
	static Statement statement;
	static Connection connection;
	static {
		try {
			// Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost/checklist?user=root&password=root");

			statement = connection.createStatement();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static List<String> getSprintList() throws SQLException{

		PreparedStatement pst = connection.prepareStatement("Select * from sprint");
				  result = pst.executeQuery();
				  ArrayList<String> sprintno=new ArrayList<>();
				  while(result.next()){
					  sprintno.add(result.getString("Sprint_No"));
        }
		return sprintno;
	}

	public static Map<Integer,String> description_developerpresprint( String role) throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='Presprint'" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')" );
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerpresprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerpresprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerpresprint;
	}
	
	public static Map<Integer,String> description_developerduring(String role) throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='duringsprint'" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')");
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerduringsprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerduringsprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerduringsprint;
	}

	public static Map<Integer, String> description_developerpost(String role) throws SQLException {
		PreparedStatement pst = connection.prepareStatement("select * from checkpoints where Checkpoint_Group='postsprint'" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')");
		  result = pst.executeQuery();
		  Map<Integer,String> listDescription_developerpostsprint =new HashMap<Integer,String>();
		  while(result.next()){
			  listDescription_developerpostsprint.put(result.getInt(1),result.getString(2));
		  }
		return listDescription_developerpostsprint;
	}
	public static List<String> checklisttransaction(Object Sprint_ID,Object Role_ID,String[] checkpointlist,String Employee_ID)
	{
		Statement stmt;
		try {

			for (String checkPoint : checkpointlist) {
				Integer checkPointInt = new Integer(checkPoint);
				String query = "insert into checklist_transactions(Sprint_ID,Role_ID,CheckPoint_ID,Employee_ID) values(" + Sprint_ID
						+ ",'" + Role_ID + "','" + checkPointInt + "','" + Employee_ID + "')";
				stmt = connection.createStatement();

				stmt.executeUpdate(query);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static String role() throws SQLException {
		 String rs="";
		PreparedStatement pst = connection.prepareStatement("select * from role where Role_Description='"+LoginController.role+"'");
		  result = pst.executeQuery();
		  while(result.next()){
			  rs=result.getString(1);
		  }
		return rs;
	}
	public static String displayName(String role) throws SQLException {
        String rs = "";
        String query = "select Display_Name from users where Employee_ID= '" + LoginController.loggedInUserName +"' " + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')";
        PreparedStatement pst = connection.prepareStatement(query);

        result = pst.executeQuery();
		  while(result.next()){
			  rs=result.getString(1);
		  }
		return rs;
	
 }



	public static Set<Integer> previousSelectedItems(String selectedSprint, String role) throws SQLException {
		Set<Integer> selectedList = new HashSet<Integer>();
		String query = "select checklist_transactions.CheckPoint_ID from checklist_transactions where Sprint_ID in(select Sprint_ID from sprint where Sprint_No='"
				+ selectedSprint + "')" + " AND Role_ID in(select Role_ID from role where Role_Description='"+ role + "')" + " AND Employee_ID= '" + LoginController.loggedInUserName +"'" ;
		//System.out.println("SQL QUERY : "+query);
		PreparedStatement pst = connection.prepareStatement(query);

		result = pst.executeQuery();
		while (result.next()) {
				try{
			Integer rs = new Integer(result.getString(1));
			selectedList.add(rs);
				}catch (Exception e) {
					e.printStackTrace();
				}
		}
		return selectedList;
	}
}
