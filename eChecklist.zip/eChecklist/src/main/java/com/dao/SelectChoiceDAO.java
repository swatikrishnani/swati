package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SelectChoiceDAO {
    static ResultSet result;

    static PreparedStatement pst;

    static Connection connection = DBConnectionDAO.getConnection();

    public static List<String> getSprintList() throws SQLException {

        pst = connection.prepareStatement("Select * from sprint");
        ResultSet result = pst.executeQuery();
        ArrayList<String> sprintno = new ArrayList<>();
        while (result.next()) {
            sprintno.add(result.getString("Sprint_No"));
        }
        return sprintno;
    }

    public static Map<Integer, String> getAllRole_Description()
            throws SQLException {

        pst = connection.prepareStatement("Select * from role");
        result = pst.executeQuery();
        Map<Integer, String> rolelistDescription = 
                new HashMap<Integer, String>();
        while (result.next()) {
            rolelistDescription.put(result.getInt(1), result.getString(2));
        }
        return rolelistDescription;
    }

    public static List<String> getAllRole_ID(final String role) throws SQLException {
        ArrayList<String> listDescription = null;

        pst = connection.prepareStatement(
                "Select * from role where Role_Description='" + role + "'");
        result = pst.executeQuery();
        listDescription = new ArrayList<>();

        while (result.next()) {
            listDescription.add(result.getString("Role_ID"));
        }
        return listDescription;
    }
}
