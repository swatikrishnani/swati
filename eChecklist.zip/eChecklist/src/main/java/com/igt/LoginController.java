package com.igt;

import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.LoginDAO;
import com.dao.SelectChoiceDAO;


@Controller
public class LoginController {
	public static String loggedInUserName;
	public static String[] roles;

	@RequestMapping(value = "/")
	public String welcome(final Model model) {
		model.addAttribute("name", "Home Page");
		model.addAttribute("description", "unsecured page !");
		return "login";

	}

	@RequestMapping("/login")
	public String login(@RequestParam(value = "error",
	required = false) String error,
	@RequestParam(value = "logout", required = false)
	String logout, final Model model, final HttpSession session) {

		if (error != null) {
			model.addAttribute("error", "Invalid username and "
			        + "password");
		}

		if (logout != null) {
			model.addAttribute("msg", "You have been logged out "
			        + "successfully");
			session.invalidate();
			LoginDAO.logout();
}

		return "login";
	}
	@RequestMapping("/selectchoice")
    public String admin(Authentication authentication, Model model, Principal principal) throws SQLException {

       loggedInUserName = principal.getName();

        model.addAttribute("user", loggedInUserName);
        model.addAttribute("description", "Protected page !");

        List<SimpleGrantedAuthority> authList = (List<SimpleGrantedAuthority>) authentication.getAuthorities();
        ArrayList<String> authorityList = new ArrayList<>();
        String role = "";
        for (SimpleGrantedAuthority authority : authList) {
            role = authority.getAuthority();
            authorityList.add(role);
        }
        model.addAttribute("sprintList", SelectChoiceDAO.getSprintList());

        model.addAttribute("authList", authorityList);

        return "selectchoice";
    }

	@RequestMapping(value = "/signUp", method = RequestMethod.GET)
	public String signUp(final Model model) throws SQLException {
     Map<Integer, String> roleDesciption =
		        SelectChoiceDAO.getAllRole_Description();
		model.addAttribute("roleDesciption", roleDesciption);
		return "signUp";
	}

	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public String backtologin(final HttpServletRequest
	        request) throws Exception {
		String employeeID = request.getParameter("employeeID");
		String name = request.getParameter("name");
		roles = request.getParameterValues("roles");
		String password = request.getParameter("password");
		LoginDAO.signUpTransaction(password, roles, name, employeeID);

		return "login";
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	public String forgotPassword() {

		return "forgotPassword";
	}
	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public String forgotPassword(final
	        HttpServletRequest request) throws SQLException {
		String employeeID = request.getParameter("employeeID");
		String password = request.getParameter("password");
		LoginDAO.forgotPasswordTransaction(password, employeeID);
		return "login";

	}

	@RequestMapping(value = "/backToLogin", method = RequestMethod.POST)
	public String backToLogin() {

		return "login";
	}
}
