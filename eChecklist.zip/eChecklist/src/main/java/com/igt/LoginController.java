package com.igt;

import java.io.IOException;
import java.security.Principal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.ChecklistDAO;

import javax.servlet.http.*;

@Controller
public class LoginController {
	static ResultSet rs;
	public static Object role;
	public static Object sprint;
	public static String selectedSprint;
	public static String selectedrole;
	public static String[] checkpointlist1;
	public static String[] checkpointlist2;
	public static String[] roledesciption;
	public static String loggedInUserName;
	public static String Role;

	@RequestMapping(value = "/")
	public String welcome(Model model) {
		model.addAttribute("name", "Home Page");
		model.addAttribute("description", "unsecured page !");
		return "login";

	}

	@RequestMapping(value = "/forgotPassword")
	public String forgotPassword() {

		return "forgotPassword";
	}
	/*@RequestMapping(value="/backtologin", method = RequestMethod.POST)
	public String backtologin(HttpServletRequest request) throws Exception{
		String employeeID= request.getParameter("employeeID");
		String name = request.getParameter("name");
		Role= request.getParameter("Role");
		String password = request.getParameter("password");
			List<String> signuptansaction=ChecklistDAO.signuptransaction(password,name,employeeID);
		
		
		return "login";
	}
	*/
	@RequestMapping("/postsprint")
	public String postprint(HttpServletRequest request, ModelMap model, HttpSession session) {
		try {
			
			role = session.getAttribute("role");
			sprint = session.getAttribute("sprint");
			checkpointlist1=request.getParameterValues("checkpointlist1");
			checkpointlist2=request.getParameterValues("checkpointlist2");
			String roleList = ChecklistDAO.role();
			if(checkpointlist1!=null)
			{
				
				List<String> checkpoint_transactionList = (List<String>) ChecklistDAO
						.checklisttransaction(session.getAttribute("sprint"), roleList, checkpointlist2, loggedInUserName);
			}
			if(checkpointlist2!=null)
			{
				List<String> checkpoint_updatetransaction=ChecklistDAO.checklistupdatetransaction(session.getAttribute("sprint"), roleList, checkpointlist1, loggedInUserName);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception = " + ex);
		}
		return "Valuesubmission";

	}

	@RequestMapping(value="/signUp", method = RequestMethod.GET)
	public String signUp(Model model) throws SQLException{
		List<String> roledesciption=ChecklistDAO.getAllRole_Description();
		model.addAttribute("roledesciption", roledesciption);
		return "signUp";
	}

	@RequestMapping(value = "/changePassword")
	public String changePassword(HttpServletRequest request) throws SQLException {
		String employeeID = request.getParameter("employeeID");
		String password = request.getParameter("password");

		ChecklistDAO.forgotPasswordTransaction(password, employeeID);

		return "login";

	}

	@RequestMapping(value = "/backToLogin", method = RequestMethod.POST)
	public String backToLogin() {

		return "login";
	}
	
	@RequestMapping("/login") 
	public String login( 
			@RequestParam(value="error", required = false) 
            String error, 
            @RequestParam(value="logout", required = false) 
            String logout, Model model){ 
 
		if(error != null){ model.addAttribute("error", "Invalid username and password"); 
        } 
 
		if (logout !=null){ model.addAttribute("msg", "You have been logged out successfully"); 
        } 
 
		return "login"; 
		} 

	@RequestMapping("/index")
	public String admin(Authentication authentication, Model model, Principal principal) throws SQLException {

		loggedInUserName = principal.getName();

		model.addAttribute("user", loggedInUserName);
		model.addAttribute("name", "Spring Security Custom Login Demo");
		model.addAttribute("description", "Protected page !");

		List<SimpleGrantedAuthority> authList = (List<SimpleGrantedAuthority>) authentication.getAuthorities();
		ArrayList<String> authorityList = new ArrayList<>();
		String role = "";
		for (SimpleGrantedAuthority authority : authList) {
			role = authority.getAuthority();
			authorityList.add(role);
		}
		model.addAttribute("sprintList", ChecklistDAO.getSprintList());

		model.addAttribute("authList", authorityList);

		return "selectchoice";
	}

	@RequestMapping("/backToChoice")
	public String backToChoice(Authentication authentication, Model model, Principal principal) throws SQLException {

		List<SimpleGrantedAuthority> authList = (List<SimpleGrantedAuthority>) authentication.getAuthorities();
		ArrayList<String> authorityList = new ArrayList<>();
		String role = "";
		for (SimpleGrantedAuthority authority : authList) {
			role = authority.getAuthority();
			authorityList.add(role);
		}
		model.addAttribute("sprintList", ChecklistDAO.getSprintList());

		model.addAttribute("authList", authorityList);

		return "selectchoice";
	}


	@RequestMapping(value = "/redirect", method = RequestMethod.POST)
	public String redirect(ModelMap model, HttpSession session, HttpServletRequest request) throws SQLException {
		selectedrole = request.getParameter("role");
		selectedSprint = request.getParameter("sprint");
		String role = request.getParameter("role");
		String sprint = request.getParameter("sprint");
		session.setAttribute("sprint", sprint);
		session.setAttribute("role", role);
		String Employee_Name = ChecklistDAO.displayName(selectedrole);
		Map<Integer, String> devCheckListpresprint = ChecklistDAO.description_developerpresprint(selectedrole);
		Map<Integer, String> devCheckListduringsprint = ChecklistDAO.description_developerduring(selectedrole);
		Map<Integer, String> devCheckListpostsprint = ChecklistDAO.description_developerpost(selectedrole);

		Set<Integer> selectedList = ChecklistDAO.previousSelectedItems(selectedSprint, selectedrole);
		model.addAttribute("previousSelectedItems", selectedList);
		/*
		 * while (i.hasNext()) { Map.Entry e = (Map.Entry) i.next(); Integer[] k
		 * = (Integer[]) e.getKey(); String []v = (String[]) e.getValue();
		 * session.setAttribute("k", k); session.setAttribute("v", v); }
		 */
		model.addAttribute("role", role);
		model.addAttribute("MapDescription_developerpre", devCheckListpresprint);
		model.addAttribute("MapDescription_developerduring", devCheckListduringsprint);
		model.addAttribute("MapDescription_developerpost", devCheckListpostsprint);
		model.addAttribute("Employee_Name", Employee_Name);
		/*
		 * model.addAttribute("listDescription_developer",devCheckList);
		 * System.out.println("SIZE :" + devCheckList != null ?
		 * devCheckList.size() : " ZERO" );
		 */ return "redirect";

	}

	@RequestMapping(value = "/Checklist_back", method = RequestMethod.POST)
	public String Checklist_back(ModelMap model, HttpSession session, HttpServletRequest request) throws SQLException {
		String selectedSprint = (String) session.getAttribute("sprint");
		String selectedrole = (String) session.getAttribute("role");
		Map<Integer, String> devCheckListpresprint = ChecklistDAO.description_developerpresprint(selectedrole);
		Map<Integer, String> devCheckListduringsprint = ChecklistDAO.description_developerduring(selectedrole);
		Map<Integer, String> devCheckListpostsprint = ChecklistDAO.description_developerpost(selectedrole);
		String Employee_Name = ChecklistDAO.displayName(selectedrole);
		Set<Integer> selectedList = ChecklistDAO.previousSelectedItems(selectedSprint, selectedrole);
		model.addAttribute("previousSelectedItems", selectedList);
		/*
		 * while (i.hasNext()) { Map.Entry e = (Map.Entry) i.next(); Integer[] k
		 * = (Integer[]) e.getKey(); String []v = (String[]) e.getValue();
		 * session.setAttribute("k", k); session.setAttribute("v", v); }
		 */
		model.addAttribute("Employee_Name", Employee_Name);
		model.addAttribute("role", selectedrole);
		model.addAttribute("MapDescription_developerpre", devCheckListpresprint);
		model.addAttribute("MapDescription_developerduring", devCheckListduringsprint);
		model.addAttribute("MapDescription_developerpost", devCheckListpostsprint);
		/*
		 * model.addAttribute("listDescription_developer",devCheckList);
		 * System.out.println("SIZE :" + devCheckList != null ?
		 * devCheckList.size() : " ZERO" );
		 */ return "redirect";

	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(ModelMap model) {

		model.addAttribute("message", "You have successfully logged off from application !");
		return "login";

	}

	
	@RequestMapping("/presprint")
	public String presprint(HttpServletRequest request, ModelMap model, HttpSession session) {
		try {
			role = session.getAttribute("role");
			sprint = session.getAttribute("sprint");
			checkpointlist1=request.getParameterValues("checkpointlist1");
			checkpointlist2=request.getParameterValues("checkpointlist2");
			String roleList = ChecklistDAO.role();
			if(checkpointlist1!=null)
			{
				
				List<String> checkpoint_transactionList = (List<String>) ChecklistDAO
						.checklisttransaction(session.getAttribute("sprint"), roleList, checkpointlist2, loggedInUserName);
			}
			if(checkpointlist2!=null)
			{
				List<String> checkpoint_updatetransaction=ChecklistDAO.checklistupdatetransaction(session.getAttribute("sprint"), roleList, checkpointlist1, loggedInUserName);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception = " + ex);
		}
		return "Valuesubmission";

	}

	
	@RequestMapping("/duringsprint")
	public String duringsprint(HttpServletRequest request, ModelMap model, HttpSession session) {
		try {
			role = session.getAttribute("role");
			sprint = session.getAttribute("sprint");
			checkpointlist1=request.getParameterValues("checkpointlist1");
			checkpointlist2=request.getParameterValues("checkpointlist2");
			String roleList = ChecklistDAO.role();
			if(checkpointlist1!=null)
			{
				
				List<String> checkpoint_transactionList = (List<String>) ChecklistDAO
						.checklisttransaction(session.getAttribute("sprint"), roleList, checkpointlist2, loggedInUserName);
			}
			if(checkpointlist2!=null)
			{
				List<String> checkpoint_updatetransaction=ChecklistDAO.checklistupdatetransaction(session.getAttribute("sprint"), roleList, checkpointlist1, loggedInUserName);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exception = " + ex);
		}
		return "Valuesubmission";

	}

}
