package com.igt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dao.ChecklistDAO;
import com.model.Checkpoint;

@Controller
public class ChecklistController {
    public static Object role;
    public static Object sprint;
    public static String[] checkpointList;
    public static String[] remarks;


    @RequestMapping("/submitValue")
    public String postprint(final HttpServletRequest request,
            final ModelMap model,
            final HttpSession session) {
        try {
            role = session.getAttribute("role");
            sprint = session.getAttribute("sprint");
            checkpointList = request.getParameterValues("checkpointlist");
            remarks = request.getParameterValues("remarks");
            session.setAttribute("remarks", remarks);
            List<String> list = Arrays.asList(checkpointList);
            String roleList = ChecklistDAO.role();

            Map<Integer, String> selectedList = ChecklistDAO
                    .previousSelectedItems(sprint, role, 0);

            List<String> selectedListAsString = ((Collection<String>) selectedList).stream()
                    .map(s -> s.toString()).collect(Collectors.toList());
            model.addAttribute("previousSelectedItems", selectedList);
            List<Checkpoint> checkpoints = new ArrayList<>();
            // TODO --
            for(int i =0 ;i<list.size();i++){
                Checkpoint checkpoint = new Checkpoint();
                checkpoint.setCheckpointDesc(new Integer(list.get(i)));
                checkpoint.setRemark(remarks[i]);
                checkpoint.setEmployeeID(LoginController.loggedInUserName);
                checkpoint.setEnabled(0);
                checkpoint.setRoleId(roleList);
                checkpoint.setSprintNumber(session.getAttribute("sprint"));
                checkpoints.add(checkpoint);

            }

            if (selectedList.isEmpty()) {
                ChecklistDAO.checklistTransaction(checkpoints);
            } else {
                List<String> filterListToInsert = new LinkedList<String>(
                        Arrays.asList(checkpointList));
                List<String> itemsToDelete = new ArrayList<>();
                ListIterator<String> itr = selectedListAsString.listIterator();
                while (itr.hasNext()) {
                    String item = itr.next();
                    if (selectedListAsString.contains(item)) {
                        filterListToInsert.remove(item);
                    }
                    if (!list.contains(item)) {
                        itemsToDelete.add(item);
                    }
                }
                ChecklistDAO.checklistTransaction(checkpoints);
                ChecklistDAO.checklistdeletetransaction(
                        session.getAttribute("sprint"), roleList,
                        itemsToDelete.toArray(new String[itemsToDelete.size()]),
                        LoginController.loggedInUserName);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Exception = " + ex);
        }
        return "valueSubmission";

    }

  @RequestMapping("/submitSprint")
    public String submitsprint(final HttpServletRequest request,
            final ModelMap model,
            final HttpSession session) {
        try {
            role = session.getAttribute("role");
            sprint = session.getAttribute("sprint");
            checkpointList = request.getParameterValues("checkpointlist");
            remarks = request.getParameterValues("remarks");
            List<String> list = Arrays.asList(checkpointList);
            String roleList = ChecklistDAO.role();

            Map<Integer, String> selectedList = ChecklistDAO
                    .previousSelectedItems(sprint, role, 0);

            List<String> selectedListAsString = ((Collection<String>) selectedList).stream()
                    .map(s -> s.toString()).collect(Collectors.toList());

            model.addAttribute("previousSelectedItems", selectedList);
            List<Checkpoint> checkpoints = new ArrayList<>();
            // TODO --
            for(int i =0 ;i<list.size();i++){
                Checkpoint checkpoint = new Checkpoint();
                checkpoint.setCheckpointDesc(new Integer(list.get(i)));
                checkpoint.setRemark(remarks[i]);
                checkpoint.setEmployeeID(LoginController.loggedInUserName);
                checkpoint.setEnabled(1);
                checkpoint.setRoleId(roleList);
                checkpoint.setSprintNumber(session.getAttribute("sprint"));
                checkpoints.add(checkpoint);

            }

            if (selectedList.isEmpty()) {
                ChecklistDAO.checklistTransaction(checkpoints);
            } else {
                List<String> filterListToInsert = new LinkedList<String>(
                        Arrays.asList(checkpointList));
                List<String> filterListToUpdate = new LinkedList<String>(
                        selectedListAsString);
                List<String> itemsToDelete = new ArrayList<>();
                ListIterator<String> itr = selectedListAsString.listIterator();
                while (itr.hasNext()) {
                    String item = itr.next();
                    if (selectedListAsString.contains(item)) {

                        filterListToInsert.remove(item);
                    }

                    if (!list.contains(item)) {
                        itemsToDelete.add(item);
                    }

                }
                ChecklistDAO.EnabledTransaction(session.getAttribute("sprint"),
                        roleList,
                        filterListToUpdate
                                .toArray(new String[filterListToUpdate.size()]),
                        LoginController.loggedInUserName);
                ChecklistDAO.checklistTransaction(checkpoints);
                ChecklistDAO.checklistdeletetransaction(
                        session.getAttribute("sprint"), roleList,
                        itemsToDelete.toArray(new String[itemsToDelete.size()]),
                        LoginController.loggedInUserName);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Exception = " + ex);
        }
        return "valueSubmission";

    }

}
