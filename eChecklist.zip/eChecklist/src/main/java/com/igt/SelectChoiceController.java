package com.igt;
import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dao.ChecklistDAO;
import com.dao.SelectChoiceDAO;
import com.model.Checkpoint;

@Controller
public class SelectChoiceController {
	public static String selectedSprint;
	public static String selectedRole;
	public static String[] checkpointlist;
	public static String[] roledesciption;
	public static String[] remarks;

    @RequestMapping("/backToChoice")
    public String backToChoice(final Authentication authentication,
            final Model model, final Principal principal) throws SQLException {

		@SuppressWarnings("unchecked")
        List<SimpleGrantedAuthority> authList =
        (List<SimpleGrantedAuthority>) authentication
                .getAuthorities();
		ArrayList<String> authorityList = new ArrayList<>();
		String role = "";
		for (SimpleGrantedAuthority authority : authList) {
			role = authority.getAuthority();
			authorityList.add(role);
		}
        model.addAttribute("sprintList", SelectChoiceDAO.getSprintList());

        model.addAttribute("authList", authorityList);

        return "selectChoice";
	}


    @RequestMapping(value = "/checklist", method = RequestMethod.POST)
    public String redirect(final ModelMap model,final HttpSession session,
            final HttpServletRequest request) throws SQLException {
		selectedRole = request.getParameter("role");
		selectedSprint = request.getParameter("sprint");
		String role = request.getParameter("role");
		String sprint = request.getParameter("sprint");

		session.setAttribute("sprint", sprint);
		session.setAttribute("role", role);


		String Employee_Name = ChecklistDAO.displayName(selectedRole);
        Map<Integer, String> devCheckListpresprint = ChecklistDAO
                .description_developerpresprint(selectedRole);
        Map<Integer, String> devCheckListduringsprint = ChecklistDAO
                .description_developerduring(selectedRole);
        Map<Integer, String> devCheckListpostsprint = ChecklistDAO
                .description_developerpost(selectedRole);
        Map<Integer, String> selectedList = ChecklistDAO
                .previousSelectedItems(selectedSprint, selectedRole, 0);
        model.addAttribute("previousSelectedItems", selectedList);
        Map<Integer, String> submitselectedList = ChecklistDAO
                .previousSelectedItems(selectedSprint, selectedRole, 1);

        model.addAttribute("submitselectedList", submitselectedList);
        model.addAttribute("role", role);
        model.addAttribute("MapDescription_developerpre",
                devCheckListpresprint);
        model.addAttribute("MapDescription_developerduring",
                devCheckListduringsprint);
        model.addAttribute("MapDescription_developerpost",
                devCheckListpostsprint);
        model.addAttribute("Employee_Name", Employee_Name);
		return "redirect";

	}

	@RequestMapping(value = "/backToChecklist", method = RequestMethod.POST)
    public String Checklist_back(final ModelMap model,
            final HttpSession session, final HttpServletRequest request)
                    throws SQLException {
        String selectedSprint = (String) session.getAttribute("sprint");
        String selectedrole = (String) session.getAttribute("role");
        Object remarks = session.getAttribute("remarks");
        List<Checkpoint> checkpoints = new ArrayList<>();
        Map<Integer, String> devCheckListpresprint = ChecklistDAO
                .description_developerpresprint(selectedrole);
        Map<Integer, String> devCheckListduringsprint = ChecklistDAO
                .description_developerduring(selectedrole);
        Map<Integer, String> devCheckListpostsprint = ChecklistDAO
                .description_developerpost(selectedrole);
        String Employee_Name = ChecklistDAO.displayName(selectedrole);

        Map<Integer, String> selectedList = ChecklistDAO.previousSelectedItems(selectedSprint, selectedrole, 0);
        model.addAttribute("previousSelectedItems", selectedList);
        Map<Integer, String> submitselectedList = ChecklistDAO
                .previousSelectedItems(selectedSprint, selectedrole, 1);
        model.addAttribute("submitselectedList", submitselectedList);
        model.addAttribute("Employee_Name", Employee_Name);
        model.addAttribute("role", selectedrole);
        model.addAttribute("MapDescription_developerpre",
                devCheckListpresprint);
        model.addAttribute("MapDescription_developerduring",
                devCheckListduringsprint);
        model.addAttribute("MapDescription_developerpost",
                devCheckListpostsprint);
        return "redirect";

	}

}
