function myfunc() {
	$('#a').get(0).reset()
	$('#b').get(0).reset()
	$('#c').get(0).reset()
}

function Validate() {
	$("input").attr("required", "true");
	var password = document.getElementById("password").value;
	var confirmPassword = document.getElementById("password_confirmation").value;
	if (password != confirmPassword) {
		alert("Passwords do not match..!!!");
		return false;
	}
	return true;
}

function validateLogin() {
	$("input").attr("required", "true");
}

function openPage(pageURL) {
    window.location = pageURL;
}
function SelectRedirect(){
	switch(document.getElementById('s1').value)
	{
	case "ROLE_TESTER_FAT":
	window.location="../views/TesterFATChecklist.jsp";
	break;

	case "ROLE_TESTER_INTEGRATION":
	window.location="../views/TesterIntegration.jsp";
	break;

	case "ROLE_TESTER_CI":
	window.location="../views/TesterCIChecklist.jsp";
	break;

	default:
	window.location="../"; 
	break;
	}
	}

function Validate() {
	$("input").attr("required", "true");
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("password_confirmation").value;
    if (password != confirmPassword) {
        alert("Passwords do not match..!!!");
        return false;
    }
    return true;
}
