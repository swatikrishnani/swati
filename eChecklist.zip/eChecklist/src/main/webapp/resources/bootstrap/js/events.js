


function Validate() {
	$("input").attr("required", "true");
	var password = document.getElementById("password").value;
	var confirmPassword = document.getElementById("password_confirmation").value;
	if (password != confirmPassword) {
		alert("Passwords do not match..!!!");
		return false;
	}
	return true;
}

function validateLogin() {
	$("input").attr("required", "true");
}

function openPage(pageURL) {
    window.location = pageURL;
}
function SelectRedirect(){
	switch(document.getElementById('s1').value)
	{
	case "ROLE_TESTER_FAT":
	window.location="../views/TesterFATChecklist.jsp";
	break;

	case "ROLE_TESTER_INTEGRATION":
	window.location="../views/TesterIntegration.jsp";
	break;

	case "ROLE_TESTER_CI":
	window.location="../views/TesterCIChecklist.jsp";
	break;

	default:
	window.location="../"; 
	break;
	}
	}


$(document).ready(function(){
    // Add minus icon for collapse element which is open by default
    $(".collapse.in").each(function(){
    	$(this).siblings(".panel-heading").find(".glyphicon").addClass("glyphicon-minus").removeClass("glyphicon-plus");
    });
    
    // Toggle plus minus icon on show hide of collapse element
    $(".collapse").on('show.bs.collapse', function(){
    	$(this).parent().find(".glyphicon").removeClass("glyphicon-plus").addClass("glyphicon-minus");
    }).on('hide.bs.collapse', function(){
    	$(this).parent().find(".glyphicon").removeClass("glyphicon-minus").addClass("glyphicon-plus");
    });
});