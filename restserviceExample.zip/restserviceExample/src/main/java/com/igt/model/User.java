package com.igt.model;

import java.io.Serializable;
public class User implements Serializable {
	private int userid;
	private String firstName;
	private String lastName;
	private String username;
    private String password;
    
public User(){
		
	}
	
	public User(int userid, String firstName, String lastName){
		this.userid = userid;
		this.firstName = firstName;	
		this.lastName = lastName;	
	}

	
   
    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
	
	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "User [userid=" + userid + ", firstName=" + firstName + ", lastName=" + lastName + ", username="
				+ username + ", password=" + password + "]";
	}

}
