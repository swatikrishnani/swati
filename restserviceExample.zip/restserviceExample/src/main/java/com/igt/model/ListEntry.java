package com.igt.model;

import java.util.List;

public class ListEntry {
	 @Override
	public String toString() {
		return "ListEntry [fieldDetails=" + fieldDetails + "]";
	}

	public List<User> fieldDetails;

	public List<User> getFieldDetails() {
		return fieldDetails;
	}

	public void setFieldDetails(List<User> fieldDetails) {
		this.fieldDetails = fieldDetails;
	}
}
