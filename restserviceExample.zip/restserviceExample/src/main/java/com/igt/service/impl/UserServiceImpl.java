package com.igt.service.impl;

import com.igt.service.UserService;

public class UserServiceImpl implements UserService{

}
