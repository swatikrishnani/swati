package com.igt.service;

public interface UserService {

}
