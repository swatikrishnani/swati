package com.igt.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.igt.model.User;


@Controller
public class UserController {

	@RequestMapping("/")
	public String homePage(Model model){
		User user = new User();
		model.addAttribute("logincommand", user);
		return "login";
	}
	
	 @RequestMapping(value="/login", method = RequestMethod.POST)
	    public String login(Model model, @ModelAttribute("logincommand") User user) {
	        if (user != null) {
	            if (user.getUsername().equals("nitika") && user.getPassword().equals("nitika")) {
	                model.addAttribute("msg", "Welcome" +"  " + user.getUsername());
	                return "welcome";
	            } else {
	                model.addAttribute("error", "Invalid Details");
	                return "login";
	            }
	        } else {
	            model.addAttribute("error", "Please enter Details");
	            return "login";
	        }
	    }
	
	@RequestMapping("/listUsers")
	public ModelAndView getAllUsers(){
		RestTemplate restTemplate = new RestTemplate();
		String url = "http://localhost:8080/restserviceExample/getUsers/";
		User users =  restTemplate.getForObject(url, User.class);
		return new ModelAndView("listUsers","users",users);
	
	}

	
	

}
