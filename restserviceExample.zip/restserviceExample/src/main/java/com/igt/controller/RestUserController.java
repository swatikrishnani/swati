package com.igt.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igt.model.User;

@RestController
public class RestUserController {
	
	@RequestMapping(value="/getUsers", method = RequestMethod.GET)
	public ResponseEntity<User> getAllUsers() {
		User user = new User();
		user.setUserid(1);
		user.setFirstName("Nitika");
		user.setLastName("Khanna");
		return new ResponseEntity<User>(user,HttpStatus.OK);
		
		
	}
}
