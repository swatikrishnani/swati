package com.igt.controller;

import java.util.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.igt.model.User;

@RestController
public class RestUserController {
	
	@RequestMapping(value="/getUsers", method = RequestMethod.GET)
	public ResponseEntity<Map<String,User>> getAllUsers() {
		Map<String,User> getallusers = new HashMap<String,User>();
		User user=new User(1,"swati","Krishnani");
		getallusers.put("1",user);
		User user1=new User(2,"nitika","Khanna");
		getallusers.put("2",user1);
		
		return new ResponseEntity<Map<String,User>>(getallusers, HttpStatus.OK);
		
	}
	@RequestMapping(value="/getUser", method = RequestMethod.GET)
	public ResponseEntity<Map<String,User>> getAllUser() {
		
		return new ResponseEntity<Map<String,User>>(HttpStatus.OK);
		
	}
}
