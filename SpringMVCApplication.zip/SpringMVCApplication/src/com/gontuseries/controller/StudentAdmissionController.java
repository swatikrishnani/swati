package com.gontuseries.controller;


import java.text.SimpleDateFormat;
import java.util.Date;
import javax.validation.Valid;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentAdmissionController 
{
	
	  // Here we used init binder and web data web data binder for disable feild.
	
	 // after that we used property editor for provide our own property editor  ( custom date editor)
	 // spring mvc have some build in property editor classic 
	   // custom date editor
	  // custom  number editor 
	 // custom  boolean editor
   
	  @InitBinder
	  public void initBinder(WebDataBinder binder)
	  {
		 // binder.setDisallowedFields(new String[] { "studentMobile"});
		  
		  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy****mm**dd");
		  binder.registerCustomEditor(Date.class,"studentDOB", new CustomDateEditor(dateFormat, false));
		  binder.registerCustomEditor(String.class, "studentName", new StudentNameEditor());
		  
		  
	  }
	
	
	
	  @RequestMapping(value = "/admissionForm.html",  method  = RequestMethod.GET)
    	public ModelAndView getAdmmissionForm()
    	{
    		ModelAndView modelandview = new ModelAndView("AdmissionForm");
    		
    		//modelandview.addObject("HeaderMessage", "Interglobe Technologies ");
    		
    		return modelandview;
    	}
	  
	  //Spring mvc call this method first before any other controller  method .
	  @ModelAttribute
	  public void addingCommonObjects(Model  modelandview)
	  {
		  modelandview.addAttribute("headerMessage", " Interglobe Technologies");
	  }
    
    /*@RequestMapping(value = "/submitAdmissionForm.html",  method  = RequestMethod.POST)
	public ModelAndView submitAdmmissionForm(@RequestParam(value = "studentName"  )String name, @RequestParam("studentHobby")String hobby)
	{
    	Student student1 = new Student();
    	student1.setStudentName(name);
    	student1.setStudentHobby(hobby);
    	
		ModelAndView modelandview = new ModelAndView("AdmissionSuccess");
		
		modelandview.addObject("HeaderMessage", "Interglobe Technologies ");
		modelandview.addObject("student1", student1);
		return modelandview;
	}*/
	  // Same process using @model Attribute
	  
    @RequestMapping(value = "/submitAdmissionForm.html",  method  = RequestMethod.POST)
   	public ModelAndView submitAdmmissionForm(@Valid @ModelAttribute("student1") Student student1, BindingResult result)
   	{
       if(result.hasErrors())
       {
    	   ModelAndView modelandview = new ModelAndView("AdmissionForm");
    		return modelandview;
       }
       	
   		ModelAndView modelandview = new ModelAndView("AdmissionSuccess");
   		
   		//modelandview.addObject("HeaderMessage", "Interglobe Technologies ");
   
   		return modelandview;
   	}
	  
	 /* @RequestMapping(value = "/submitAdmissionForm.html",  method  = RequestMethod.POST)
		public ModelAndView submitAdmmissionForm(@RequestParam Map<String,String> reqPar)
		{
		   String name =  reqPar.get("studentName");
		   String hobby = reqPar.get("studentHobby");
		  
			ModelAndView modelandview = new ModelAndView("AdmissionSuccess");
			
			modelandview.addObject("msg", "Details submitted by you : :Name "+name+",  Hobby :"+hobby);
			return modelandview;
		}*/
}
